import torch
from typing import Dict, Tuple

def calculate_rewards_and_dones_jit(
    # 包含了所有超参数的字典，方便传入JIT函数
    h_params: Dict[str, float],
    # 包含世界状态的张量
    all_pos: torch.Tensor,
    all_vel: torch.Tensor,
    p_vels: torch.Tensor,
    raw_actions: torch.Tensor,
    basket_pos: torch.Tensor,
    spot_center_pos: torch.Tensor,
    t_remaining: torch.Tensor,
    # 需要在函数内部更新并返回的状态张量
    a1_still_frames_counter: torch.Tensor,
    wall_collision_counters: torch.Tensor,
    defender_over_midline_counter: torch.Tensor,
    dones: torch.Tensor,
    # 预先计算好的交互张量
    dist_matrix: torch.Tensor,
    collision_matrix: torch.Tensor,
    vel_diffs_norm: torch.Tensor,
    requested_accelerations_tensor: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    JIT编译函数，用于以矢量化方式计算奖励和回合终止信号。
    此函数是自包含的，不访问任何类属性，以确保JIT兼容性。

    返回:
        dense_reward (Tensor): 所有智能体在当前步的稠密奖励
        terminal_rewards (Tensor): 所有智能体的终局奖励 (仅在回合结束时非零)
        dones_out (Tensor): 所有环境的终止标志
        a1_still_frames_counter (Tensor): 更新后的A1静止计数器
        wall_collision_counters (Tensor): 更新后的撞墙计数器
        defender_over_midline_counter (Tensor): 更新后的防守方越线计数器
        shots_this_step (Tensor): 标记哪些环境在当前步发生了投篮
    """
    # 从输入中提取维度和常量
    batch_dim, n_agents, _ = all_pos.shape
    device = all_pos.device
    n_attackers = 2
    n_defenders = 2
    
    # 初始化返回的张量
    terminal_rewards = torch.zeros(batch_dim, n_agents, device=device)
    dense_reward = torch.zeros(batch_dim, n_agents, device=device)
    dones_out = dones.clone()  # 复制一份，避免在函数内部直接修改输入
    attacker_win_this_step = torch.zeros(batch_dim, device=device, dtype=torch.bool)

    # =================================================================================
    # 第一部分: 回合终止条件检查 (逻辑源自原始的 check_done 方法)
    # =================================================================================

    # --- 条件1: 尝试投篮 (Shot Attempt) ---
    a1_pos = all_pos[:, 0]
    a1_vel = all_vel[:, 0]
    # A1到投篮点的距离
    dist_to_spot = torch.linalg.norm(a1_pos - spot_center_pos, dim=1)
    # 条件a: 在投篮区域内 (且在进攻半场)
    in_area = (dist_to_spot <= h_params['R_spot']) & (a1_pos[:, 1] > 0)
    # 条件b: 速度足够低，视为“静止”
    is_still = torch.linalg.norm(a1_vel, dim=1) < h_params['v_shot_threshold']
    # 条件c: 原始动作(意图)很小，视为“无加速意图”
    not_accelerating = torch.linalg.norm(raw_actions[:, 0, :], dim=1) < h_params['a_shot_threshold']

    # 综合判断是否满足“准备投篮”的状态
    is_ready_to_shoot = in_area & is_still & not_accelerating
    # 如果满足准备条件，计数器加一；否则清零
    a1_still_frames_counter = torch.where(is_ready_to_shoot, a1_still_frames_counter + 1, 0)
    
    # 如果连续满足准备条件的帧数达到阈值，则触发投篮事件
    shot_attempted = (a1_still_frames_counter >= h_params['shot_still_frames']) & ~dones_out
    if torch.any(shot_attempted):
        attacker_win_this_step |= shot_attempted
        shot_b_idx = shot_attempted.nonzero().squeeze(-1)
        
        # --- 提取投篮瞬间的关键状态信息 ---
        a1_pos_shot = a1_pos[shot_b_idx]
        a2_pos_shot = all_pos[shot_b_idx, 1]
        spot_pos_shot = spot_center_pos[shot_b_idx]
        basket_pos_shot = basket_pos[shot_b_idx]
        defender_pos_shot = all_pos[shot_b_idx][:, 2:]

        # --- 计算防守方的综合封堵/干扰系数 ---
        shot_vector = basket_pos_shot - a1_pos_shot  # 投篮向量
        blocker_vector = defender_pos_shot - a1_pos_shot.unsqueeze(1)  # A1到防守者的向量
        shot_vector_norm_sq = torch.sum(shot_vector**2, dim=-1, keepdim=True) + 1e-6
        # 计算防守者在投篮向量上的投影长度比例
        dot_product = torch.sum(blocker_vector * shot_vector.unsqueeze(1), dim=-1)
        proj_len_ratio = dot_product / shot_vector_norm_sq
        # 判断防守者是否在A1和篮筐之间
        is_between = (proj_len_ratio > 0) & (proj_len_ratio < 1)
        # 计算防守者到投篮线的垂直距离的平方
        projection = proj_len_ratio.unsqueeze(-1) * shot_vector.unsqueeze(1)
        dist_perp_sq = torch.sum((blocker_vector - projection)**2, dim=-1)
        # 判断防守者是否足够近构成封堵
        is_blocker_per_defender = is_between & (dist_perp_sq < (h_params['proximity_threshold'])**2)
        # 使用高斯函数计算每个防守者的封堵贡献，距离越近贡献越大
        block_contribution = torch.exp(-dist_perp_sq / (2 * h_params['block_sigma']**2)) * is_blocker_per_defender.float()
        # 将所有防守者的贡献相加，并限制在[0, 1]之间，得到总的封堵因子
        total_block_factor = torch.clamp(block_contribution.sum(dim=1), 0, 1)

        # --- 计算进攻方终局奖励 ---
        # 基础得分：离投篮点中心越近，得分越高
        base_score = h_params['max_score'] * (1 - dist_to_spot[shot_b_idx] / h_params['R_spot'])
        # 最终得分：基础得分乘以 (1 - 封堵因子)，封堵越严重，得分越低
        final_score_modified = base_score * (1 - total_block_factor)

        # 新增：时间奖励，投篮越早，奖励越高
        time_bonus = h_params['k_time_bonus'] * (t_remaining[shot_b_idx].squeeze(-1) / h_params['t_limit'])

        # 空间奖励：A1与防守者的平均距离越大，获得的额外奖励越高
        dist_a1_to_defs = torch.linalg.norm(blocker_vector, dim=-1)
        avg_dist_to_defs = torch.mean(dist_a1_to_defs, dim=1)
        spacing_bonus = h_params['k_spacing_bonus'] * avg_dist_to_defs
        # A1的总奖励 = 最终得分 + 空间奖励 + 时间奖励
        a1_reward = final_score_modified + spacing_bonus + time_bonus
        terminal_rewards[shot_b_idx, 0] += a1_reward

        # --- 计算A2的奖励 ---
        # 识别离A1最近的、威胁最大的防守者
        dist_a1_to_defs_sq = torch.sum(blocker_vector**2, dim=-1)
        _, closest_def_indices = torch.min(dist_a1_to_defs_sq, dim=1)
        batch_indices = torch.arange(len(shot_b_idx), device=device)
        p_closest_def = defender_pos_shot[batch_indices, closest_def_indices]
        
        # 计算A2的理想掩护位置 (在A1和关键防守者之间，靠近防守者)
        def_to_a1_vec = a1_pos_shot - p_closest_def
        def_to_a1_norm = torch.linalg.norm(def_to_a1_vec, dim=-1, keepdim=True) + 1e-6
        def_to_a1_unit_vec = def_to_a1_vec / def_to_a1_norm
        ideal_screen_pos = p_closest_def + h_params['screen_pos_offset'] * def_to_a1_unit_vec
        
        # A2的个人掩护奖励：基于A2当前位置与理想位置的距离 (高斯奖励)
        dist_a2_to_ideal_sq = torch.sum((a2_pos_shot - ideal_screen_pos)**2, dim=-1)
        # 使用Sigmoid门控，确保只有当A2确实在A1和防守者之间时，掩护奖励才生效
        vec_a2_to_def = p_closest_def - a2_pos_shot
        vec_a2_to_a1 = a1_pos_shot - a2_pos_shot
        dot_product_gate = torch.sum(vec_a2_to_def * vec_a2_to_a1, dim=-1)
        screen_gate = torch.sigmoid(-h_params['k_screen_gate'] * dot_product_gate) # A2在中间时，点积为负，gate接近1
        # 计算最终的掩护绩效奖励
        screen_bonus = h_params['k_a2_screen_bonus'] * torch.exp(-dist_a2_to_ideal_sq / (2 * h_params['a2_screen_sigma']**2)) * screen_gate
        # A2的总奖励 = 团队得分 + 个人掩护绩效 + 空间奖励 + 时间奖励
        a2_reward = final_score_modified + screen_bonus + spacing_bonus + time_bonus
        terminal_rewards[shot_b_idx, 1] += a2_reward

        # --- 计算防守方终局奖励 ---
        for i in range(n_defenders):
            # 奖励1: 成功干扰奖励 (基于该防守者对投篮的直接封堵贡献)
            R_block = h_params['k_def_block_reward'] * block_contribution[:, i]
            # 奖励2: 成功逼迫奖励 (A1被迫在远离投篮点中心出手，是团队防守的结果，两个防守者都获得此奖励)
            dist_a1_to_spot_shot = dist_to_spot[shot_b_idx]
            R_force = h_params['k_def_force_reward'] * (dist_a1_to_spot_shot / h_params['R_spot'])
            
            # 奖励3: 成功卡位奖励 (基于防守者是否占据了A1和篮筐之间的有利位置)
            a1_to_spot_unit_vec = (basket_pos_shot - a1_pos_shot) / (torch.linalg.norm(basket_pos_shot - a1_pos_shot, dim=-1, keepdim=True) + 1e-6)
            d_from_a1_vec = defender_pos_shot[:, i, :] - a1_pos_shot
            proj_dot = torch.sum(d_from_a1_vec * a1_to_spot_unit_vec, dim=-1)
            pos_gate = torch.sigmoid(5.0 * proj_dot) # 在A1前方时，gate接近1
            ideal_pos = a1_pos_shot + h_params['def_pos_offset'] * a1_to_spot_unit_vec
            dist_to_ideal_sq = torch.sum((defender_pos_shot[:, i, :] - ideal_pos)**2, dim=-1)
            positioning_reward_factor = torch.exp(-dist_to_ideal_sq / (2 * h_params['def_pos_sigma']**2))
            R_positioning = h_params['k_def_pos_reward'] * positioning_reward_factor * pos_gate
            
            # 奖励4: 区域控制奖励 (基于防守者对投篮热区的控制)
            dist_def_to_spot_sq = torch.sum((defender_pos_shot[:, i, :] - spot_pos_shot)**2, dim=-1)
            R_area_control = h_params['k_def_area_reward'] * torch.exp(-dist_def_to_spot_sq / (2 * h_params['def_gaussian_spot_sigma']**2))
            
            # 防守方总奖励 = 各项奖励之和 - 放任投篮的基础惩罚
            total_def_reward = R_block + R_force + R_positioning + R_area_control - h_params['k_def_shot_penalty']
            terminal_rewards[shot_b_idx, n_attackers + i] += total_def_reward
        
        # 标记这些环境的回合已结束
        dones_out |= shot_attempted

    # --- 条件2: 时间耗尽 (Time Up) ---
    time_up = (t_remaining.squeeze(-1) <= 0) & ~dones_out
    if torch.any(time_up):
        # 进攻方受到惩罚，惩罚大小与A1离投篮点的距离有关，距离越远惩罚越大
        a1_pos_timeout = a1_pos[time_up]
        dist_a1_to_spot_timeout = torch.linalg.norm(a1_pos_timeout - spot_center_pos[time_up], dim=-1)
        attacker_penalty = -h_params['R_foul'] - h_params['k_timeout_dist_penalty'] * dist_a1_to_spot_timeout
        terminal_rewards[time_up, :n_attackers] = attacker_penalty.unsqueeze(-1)
        # 防守方获得对应的奖励
        terminal_rewards[time_up, n_attackers:] = -attacker_penalty.unsqueeze(-1)
        dones_out |= time_up
    
    # --- 条件3: 碰撞犯规 (Foul) ---
    # 条件：发生碰撞 & 相对速度超过犯规阈值 & 回合尚未结束
    is_foul = collision_matrix & (vel_diffs_norm > h_params['v_foul_threshold']) & ~dones_out.view(-1, 1, 1)
    if torch.triu(is_foul, diagonal=1).any(): # 使用上三角矩阵避免重复计算每一对碰撞
        # 先获取 (K, 3) 的索引张量
        foul_indices = torch.triu(is_foul, diagonal=1).nonzero()
        # 通过 .T 转置为 (3, K) 的张量后解包
        b_idx = foul_indices[:, 0]
        i_idx = foul_indices[:, 1]
        j_idx = foul_indices[:, 2]
        # 犯规惩罚大小与碰撞的相对速度挂钩，速度越快，惩罚/奖励越大
        relative_speeds = vel_diffs_norm[b_idx, i_idx, j_idx]
        dynamic_foul_magnitude = h_params['R_foul'] + h_params['k_foul_vel_penalty'] * relative_speeds
        
        # 判断谁是主动撞人者（犯规方）
        agent_i_p_vel = p_vels[b_idx, i_idx]
        pos_rel = all_pos[b_idx, j_idx] - all_pos[b_idx, i_idx]
        vel_rel_on_pos = torch.einsum("bd,bd->b", agent_i_p_vel, pos_rel) # 速度在相对位置向量上的投影
        i_is_active = vel_rel_on_pos > 0 # 投影为正，说明i正朝向j移动
        active_indices = torch.where(i_is_active, i_idx, j_idx)
        passive_indices = torch.where(i_is_active, j_idx, i_idx)
        
        # 判断是敌方犯规还是“友好误伤”
        active_is_attacker = active_indices < n_attackers
        passive_is_attacker = passive_indices < n_attackers
        is_friendly_fire = (active_is_attacker == passive_is_attacker)
        
        foul_rewards = torch.zeros_like(terminal_rewards)
        # 处理敌方犯规
        opp_foul_mask = ~is_friendly_fire
        if torch.any(opp_foul_mask):
            opp_b = b_idx[opp_foul_mask]
            opp_active = active_indices[opp_foul_mask]
            opp_passive = passive_indices[opp_foul_mask]
            opp_magnitude = dynamic_foul_magnitude[opp_foul_mask]
            
            # 建立队友索引映射 (0->1, 1->0, 2->3, 3->2)
            teammate_map = torch.tensor([1, 0, 3, 2], device=device, dtype=torch.long)
            opp_active_teammate = teammate_map[opp_active]
            opp_passive_teammate = teammate_map[opp_passive]
            
            num_opp_fouls = opp_b.shape[0]
            opp_rewards_to_add = torch.zeros(num_opp_fouls, n_agents, device=device)
            opp_row_indices = torch.arange(num_opp_fouls, device=device)

            # 分配奖励和惩罚：
            opp_rewards_to_add[opp_row_indices, opp_active] = -opp_magnitude  # 犯规者受罚
            opp_rewards_to_add[opp_row_indices, opp_passive] = opp_magnitude   # 受害者获奖
            opp_rewards_to_add[opp_row_indices, opp_active_teammate] = -opp_magnitude * h_params['foul_teammate_factor'] # 犯规者队友受牵连
            opp_rewards_to_add[opp_row_indices, opp_passive_teammate] = opp_magnitude * h_params['foul_teammate_factor']  # 受害者队友获益
            
            opp_active_is_defender = opp_active >= n_attackers
            b_idx_def_foul = opp_b[opp_active_is_defender]
            attacker_win_this_step[b_idx_def_foul] = True
            foul_rewards.index_add_(0, opp_b, opp_rewards_to_add)

        # 处理友好误伤
        ff_foul_mask = is_friendly_fire
        if torch.any(ff_foul_mask):
            ff_b = b_idx[ff_foul_mask]
            ff_active = active_indices[ff_foul_mask]
            ff_passive = passive_indices[ff_foul_mask]
            ff_magnitude = dynamic_foul_magnitude[ff_foul_mask]

            num_ff_fouls = ff_b.shape[0]
            ff_rewards_to_add = torch.zeros(num_ff_fouls, n_agents, device=device)
            ff_row_indices = torch.arange(num_ff_fouls, device=device)

            # 友好误伤，两人都受罚
            ff_rewards_to_add[ff_row_indices, ff_active] = -ff_magnitude
            ff_rewards_to_add[ff_row_indices, ff_passive] = -ff_magnitude
            
            # 如果友好误伤发生在防守方之间，则算作进攻方胜利
            ff_active_is_attacker = active_is_attacker[ff_foul_mask]
            is_defender_ff = ~ff_active_is_attacker
            if torch.any(is_defender_ff):
                b_idx_def_ff = ff_b[is_defender_ff]
                attacker_win_this_step[b_idx_def_ff] = True

            
            foul_rewards.index_add_(0, ff_b, ff_rewards_to_add)

        terminal_rewards += foul_rewards
        dones_out[b_idx] = True

    # --- 条件4: 持续撞墙导致超时 (Wall Collision Timeout) ---
    is_wall_timeout = (wall_collision_counters >= h_params['wall_collision_frames']) & ~dones_out.view(-1, 1)
    if torch.any(is_wall_timeout):
        # 找到是哪个环境的哪个智能体触发了超时
        # 先获取 (K, 2) 的索引张量
        wall_indices = is_wall_timeout.nonzero()
        # 通过 .T 转置为 (2, K) 的张量后解包
        b_idx = wall_indices[:, 0]
        agent_idx = wall_indices[:, 1]
        is_defender_wall_collision = agent_idx >= n_attackers
        b_idx_def_wall_coll = b_idx[is_defender_wall_collision]
        attacker_win_this_step[b_idx_def_wall_coll] = True
        # 对该智能体施加巨大惩罚
        terminal_rewards[b_idx, agent_idx] += h_params['R_wall_collision_penalty']
        # 结束该环境的回合
        dones_out[b_idx] = True

    # --- 条件5: 防守方越过中线过久犯规 (Defender Over Midline Foul) ---
    # 获取所有防守者的位置
    defender_pos = all_pos[:, n_attackers:] # Shape: (batch_dim, n_defenders, 2)
    # 检查哪些防守者越过了中线 (y < 0)
    is_over_midline = defender_pos[:, :, 1] < 0 # Shape: (batch_dim, n_defenders)

    # 更新计数器：如果越线，计数器+1；否则清零
    defender_over_midline_counter = torch.where(
        is_over_midline,
        defender_over_midline_counter + 1,
        torch.zeros_like(defender_over_midline_counter)
    )

    # 检查是否触发犯规 (且回合尚未结束)
    midline_foul_triggered = (defender_over_midline_counter >= h_params['max_time_over_midline']) & ~dones_out.view(-1, 1)
    if torch.any(midline_foul_triggered):
        # 找到是哪个环境的哪个防守者首次触发了犯规
        # b_idx, def_idx = midline_foul_triggered.nonzero(as_tuple=True)
        foul_indices = midline_foul_triggered.nonzero()
        b_idx = foul_indices[:, 0]
        
        # 标记进攻方胜利
        attacker_win_this_step[b_idx] = True
        
        # 分配奖励和惩罚
        # 犯规的防守方和其队友都受到惩罚
        terminal_rewards[b_idx, n_attackers:] -= h_params['R_midline_foul']
        
        # 结束该环境的回合
        dones_out[b_idx] = True


    # =================================================================================
    # 第二部分: 稠密奖励计算 (逻辑源自原始的 reward 方法)
    # =================================================================================
    for i in range(n_agents):
        agent_pos = all_pos[:, i]
        agent_vel = all_vel[:, i]
        is_attacker = i < n_attackers
        
        # --- 通用奖励/惩罚 (对所有智能体生效) ---
        # 1. 出界惩罚 (使用平滑函数logaddexp，在边界附近平滑过渡)
        safe_x = h_params['W'] / 2 - (h_params['agent_radius'] / 2)
        safe_y = h_params['L'] / 2 - (h_params['agent_radius'] / 2)
        oob_depth_x = torch.logaddexp(torch.tensor(0.0, device=device), (torch.abs(agent_pos[:, 0]) - safe_x) / h_params['oob_margin'])
        oob_depth_y = torch.logaddexp(torch.tensor(0.0, device=device), (torch.abs(agent_pos[:, 1]) - safe_y) / h_params['oob_margin'])
        velocity_norm = torch.linalg.norm(agent_vel, dim=1) + 1.0 # 速度越快，出界惩罚越大
        oob_reward = h_params['oob_penalty'] * h_params['oob_margin'] * (oob_depth_x + oob_depth_y) * velocity_norm
        dense_reward[:, i] += oob_reward
        
        # 2. 控制量惩罚 (鼓励智能体以更小的力完成动作，节约能量)
        raw_u_norm = torch.linalg.vector_norm(raw_actions[:, i, :], dim=1)
        dense_reward[:, i] -= h_params['k_u_penalty_general'] * raw_u_norm

        requested_a = requested_accelerations_tensor[:, i]
        
        # 后续的惩罚计算逻辑完全不变
        requested_a_norm = torch.linalg.norm(requested_a, dim=-1)
        excess_acceleration = torch.clamp(requested_a_norm - h_params['a_max'], min=0.0)
        acceleration_penalty = -h_params['k_excess_acceleration_penalty'] * (excess_acceleration ** 2)
        dense_reward[:, i] += acceleration_penalty

        # 3. 近距离惩罚 (避免智能体扎堆，使用平滑函数)
        agent_dists = dist_matrix[:, i, :]
        agent_dists_clone = agent_dists.clone() # 复制以避免修改原始张量
        agent_dists_clone[:, i] = torch.inf # 忽略与自己的距离
        collision_dist = h_params['agent_radius'] * 2
        
        if i == 0: # A1有专属的近距离参数
            is_too_close = (agent_dists_clone < h_params['a1_proximity_threshold']) & (agent_dists_clone > collision_dist)
            if torch.any(is_too_close):
                k = h_params['a1_proximity_penalty_margin']
                penetration = torch.logaddexp(torch.tensor(0.0, device=device), (h_params['a1_proximity_threshold'] - agent_dists_clone) / k) * k
                proximity_penalty = -h_params['k_a1_proximity_penalty'] * penetration
                dense_reward[:, i] += (proximity_penalty * is_too_close.float()).sum(dim=1)
        elif is_attacker: # A2使用通用的进攻方参数
            is_too_close = (agent_dists_clone < h_params['proximity_threshold']) & (agent_dists_clone > collision_dist)
            if torch.any(is_too_close):
                k = h_params['proximity_penalty_margin']
                penetration = torch.logaddexp(torch.tensor(0.0, device=device), (h_params['proximity_threshold'] - agent_dists_clone) / k) * k
                proximity_penalty = -h_params['k_proximity_penalty'] * penetration
                dense_reward[:, i] += (proximity_penalty * is_too_close.float()).sum(dim=1)
        else: # 防守方使用独立的参数
            is_too_close = (agent_dists_clone < h_params['proximity_threshold']) & (agent_dists_clone > collision_dist)
            if torch.any(is_too_close):
                k = h_params['proximity_penalty_margin']
                dist_d_to_spot = torch.linalg.norm(agent_pos - spot_center_pos, dim=-1)
                is_in_spot_area = (dist_d_to_spot <= h_params['R_spot'])
                # 在关键投篮区域内，允许防守更紧密，因此减小扎堆惩罚
                adjusted_k = torch.where(is_in_spot_area, h_params['k_def_proximity_penalty'] * (1 - h_params['proximity_penalty_reduction_in_spot']), h_params['k_def_proximity_penalty'])
                penetration = torch.logaddexp(torch.tensor(0.0, device=device), (h_params['proximity_threshold'] - agent_dists_clone) / k) * k
                proximity_penalty = -adjusted_k.unsqueeze(1) * penetration
                dense_reward[:, i] += (proximity_penalty * is_too_close.float()).sum(dim=1)
        
        # 4. 碰撞惩罚
        agent_collisions = collision_matrix[:, i, :]
        if torch.any(agent_collisions):
            # 4.1 高速碰撞惩罚 (基于相对速度)
            pos_rel = all_pos - agent_pos.unsqueeze(1)
            vel_proj = torch.einsum("bd,bnd->bn", agent_vel, pos_rel)
            is_active = vel_proj > 0 # 判断是否为主动碰撞
            active_penalty = -h_params['k_coll_active'] * vel_diffs_norm[:, i, :]
            passive_penalty = -h_params['k_coll_passive'] * vel_diffs_norm[:, i, :]
            penalty = torch.where(is_active, active_penalty, passive_penalty)
            dense_reward[:, i] += (penalty * agent_collisions.float()).sum(dim=1)

            # 4.2 低速推挤惩罚 (基于原始动作大小)
            is_low_speed_collision = agent_collisions & (vel_diffs_norm[:, i, :] < h_params['low_velocity_threshold'])
            if torch.any(is_low_speed_collision):
                raw_action_force = raw_actions[:, i, :]
                pos_diffs_agent_centric = all_pos - agent_pos.unsqueeze(1)
                pos_diffs_norm = torch.linalg.norm(pos_diffs_agent_centric, dim=-1, keepdim=True) + 1e-6
                proj_vector = (pos_diffs_agent_centric / pos_diffs_norm)
                push_force_magnitude = torch.einsum('bnd,bnd->bn', raw_action_force.unsqueeze(1).expand(-1, n_agents, -1), proj_vector)
                penalty_coeff = h_params['k_def_push_penalty'] if not is_attacker else h_params['k_push_penalty']
                push_penalty = -penalty_coeff * torch.clamp(push_force_magnitude, min=0.0) # 只惩罚“推”的力
                dense_reward[:, i] += (push_penalty * is_low_speed_collision.float()).sum(dim=1)

        # 5. 造犯规奖励 (Drawing charge reward)
        is_standing_still = torch.linalg.norm(agent_vel, dim=1) < h_params['stand_still_threshold']
        charge_drawing_reward = torch.zeros(batch_dim, device=device)
        for j in range(n_agents):
            is_opponent = (j < n_attackers) != is_attacker
            if i == j or not is_opponent:
                continue
            # 计算对手朝向自己的速度
            other_agent_pos = all_pos[:, j]
            other_agent_vel = all_vel[:, j]
            relative_pos_to_agent = agent_pos - other_agent_pos
            relative_dist = torch.linalg.norm(relative_pos_to_agent, dim=-1)
            is_within_charge_range = relative_dist < h_params['charge_drawing_range']
            dot_product = torch.sum(other_agent_vel * relative_pos_to_agent, dim=-1)
            speed_of_approach = dot_product / (relative_dist + 1e-6)
            approach_gradient = torch.clamp(speed_of_approach, min=0) # 只考虑正在靠近的情况
            # 如果自己站定，且对手在范围内高速冲向自己，则获得奖励
            reward_for_this_opponent = h_params['k_stand_still_reward'] * approach_gradient * is_standing_still.float() * is_within_charge_range.float()
            charge_drawing_reward += reward_for_this_opponent
        dense_reward[:, i] += charge_drawing_reward
        
        # --- 分角色奖励/惩罚 ---
        if i == 0: # 角色: A1 (持球进攻者)
            current_dist = torch.linalg.norm(agent_pos - spot_center_pos, dim=1)
            # 1. 高斯奖励，引导A1前往投篮点
            gaussian_reward = h_params['gaussian_scale'] * torch.exp(- (current_dist**2) / (2 * h_params['gaussian_sigma']**2))
            dense_reward[:, i] += gaussian_reward

            # 2. 速度方向奖励，引导A1的速度朝向投篮点
            vector_to_spot = spot_center_pos - agent_pos
            vector_to_spot_norm = vector_to_spot / (torch.linalg.norm(vector_to_spot, dim=1, keepdim=True) + 1e-6)
            speed_projection = torch.sum(agent_vel * vector_to_spot_norm, dim=1)
            dense_reward[:, i] += h_params['k_a1_speed_spot_reward'] * speed_projection

            # 3. 进入投篮区域内的奖励
            is_in_spot = (current_dist <= h_params['R_spot']) & (agent_pos[:, 1] > 0)
            spot_reward = h_params['k_a1_in_spot_reward'] * (1 - current_dist / h_params['R_spot']) * is_in_spot.float()
            dense_reward[:, i] += spot_reward
            
            # 4. 在投篮区域内惩罚高速移动，鼓励减速准备投篮
            velocity_penalty = -h_params['k_velocity_penalty'] * torch.linalg.norm(agent_vel, dim=1) * is_in_spot.float()
            dense_reward[:, i] += velocity_penalty

            # 5. 奖励成功保持静止以“蓄力”投篮的行为
            is_charging_shot = a1_still_frames_counter > 0
            dense_reward[:, i] += h_params['k_a1_stillness_reward'] * is_charging_shot.float()
            
            # 6. 在投篮区内且低速时，惩罚其控制量，鼓励其完全静止而不是“蠕动”
            is_at_low_speed = raw_u_norm < h_params['low_u_threshold']
            control_penalty_at_low_speed = -h_params['k_control_penalty_at_low_speed'] * raw_u_norm
            dense_reward[:, i] += control_penalty_at_low_speed * is_in_spot.float() * is_at_low_speed.float()
            
            # 7. 投篮线路被封堵惩罚
            def_pos = all_pos[:, n_attackers:]
            ap = basket_pos.unsqueeze(1) - agent_pos.unsqueeze(1)
            ad = def_pos - agent_pos.unsqueeze(1)
            proj_len_ratio_blocked = torch.einsum("bnd,bmd->bnm", ad, ap).squeeze(-1) / (torch.linalg.norm(ap, dim=-1).pow(2) + 1e-6)
            is_between_mask = (proj_len_ratio_blocked > 0) & (proj_len_ratio_blocked < 1)
            closest_point_on_line = agent_pos.unsqueeze(1) + proj_len_ratio_blocked.unsqueeze(-1) * ap
            dist_perp = torch.linalg.norm(def_pos - closest_point_on_line, dim=-1)
            dist_to_def = torch.linalg.norm(agent_pos.unsqueeze(1) - def_pos, dim=-1)
            close_enough_mask = dist_to_def < h_params['def_proximity_threshold']
            block_factor = torch.exp(-dist_perp.pow(2) / (2 * h_params['block_sigma'] ** 2))
            final_block_mask = is_between_mask & close_enough_mask
            total_block_factor = (block_factor * final_block_mask.float()).sum(dim=1)
            dense_reward[:, i] += total_block_factor * h_params['k_a1_blocked_penalty']

            # 8. 惩罚在投篮区域外的“犹豫”行为 (低速移动)
            hesitation_factor = torch.clamp((1.0 - (torch.linalg.norm(agent_vel, dim=1) / h_params['hesitate_speed_threshold'])), min=0.0)**2
            is_not_in_spot = ~is_in_spot
            hesitation_penalty = -h_params['k_hesitation_penalty'] * hesitation_factor * is_not_in_spot.float()
            dense_reward[:, i] += hesitation_penalty
        
        elif i == 1: # 角色: A2 (无球掩护者)
            # --- 准备通用变量 ---
            p_a1 = all_pos[:, 0]
            p_a2 = agent_pos # agent_pos 就是 all_pos[:, 1]
            def_pos = all_pos[:, n_attackers:]
            
            # --- 分项计算A2的各项奖励/惩罚 ---

            # 1. 计算掩护奖励 (Screening Reward)
            dist_a1_to_defs_screen = torch.linalg.norm(p_a1.unsqueeze(1) - def_pos, dim=-1)
            closest_def_indices_screen = torch.argmin(dist_a1_to_defs_screen, dim=1)
            batch_indices_screen = torch.arange(batch_dim, device=device)
            p_closest_def_screen = def_pos[batch_indices_screen, closest_def_indices_screen]
            def_to_a1_vec = p_a1 - p_closest_def_screen
            ideal_screen_pos = p_closest_def_screen + h_params['screen_pos_offset'] * (def_to_a1_vec / (torch.linalg.norm(def_to_a1_vec, dim=-1, keepdim=True) + 1e-6))
            dist_a2_to_ideal_sq = torch.sum((p_a2 - ideal_screen_pos)**2, dim=-1)
            vec_a2_to_def = p_closest_def_screen - p_a2
            vec_a2_to_a1 = p_a1 - p_a2
            dot_product_gate = torch.sum(vec_a2_to_def * vec_a2_to_a1, dim=-1)
            soft_gate_factor = torch.sigmoid(-h_params['k_screen_gate'] * dot_product_gate)
            screen_reward = h_params['k_ideal_screen_pos'] * torch.exp(-dist_a2_to_ideal_sq / (2 * h_params['screen_pos_sigma']**2)) * soft_gate_factor

            # 2. 计算阻挡A1投篮线路的惩罚 (Line Blocking Penalty)
            shot_vector = basket_pos - p_a1
            a2_vector = p_a2 - p_a1
            proj_len_ratio_a2 = torch.sum(a2_vector * shot_vector, dim=-1) / (torch.sum(shot_vector**2, dim=-1) + 1e-6)
            is_between_a2 = (proj_len_ratio_a2 > 0) & (proj_len_ratio_a2 < 1)
            dist_perp_sq_a2 = torch.sum((a2_vector - proj_len_ratio_a2.unsqueeze(-1) * shot_vector)**2, dim=-1)
            proximity_factor = torch.exp(-torch.linalg.norm(a2_vector, dim=-1).pow(2) / (2 * (2 * h_params['agent_radius'])**2))
            line_block_factor = is_between_a2.float() * torch.exp(-dist_perp_sq_a2 / (2 * (0.5 * h_params['agent_radius'])**2))
            line_penalty = h_params['k_a2_shot_line_penalty'] * line_block_factor * proximity_factor

            # 3. 计算驱离奖励 (Repulsion Reward)
            # 注意：这里的逻辑和掩护奖励类似，但为了清晰，我们重新计算
            dist_a1_to_defs_repel = torch.linalg.norm(p_a1.unsqueeze(1) - def_pos, dim=-1)
            closest_def_indices_repel = torch.argmin(dist_a1_to_defs_repel, dim=1)
            batch_indices_repel = torch.arange(batch_dim, device=device)
            p_closest_def_repel = def_pos[batch_indices_repel, closest_def_indices_repel]
            v_closest_def_repel = all_vel[batch_indices_repel, n_attackers + closest_def_indices_repel]
            a1_to_def_vec_repel = p_closest_def_repel - p_a1
            repulsion_direction = a1_to_def_vec_repel / (torch.linalg.norm(a1_to_def_vec_repel, dim=-1, keepdim=True) + 1e-6)
            repulsion_speed = torch.sum(v_closest_def_repel * repulsion_direction, dim=-1)
            dist_a2_to_closest_def = torch.linalg.norm(p_a2 - p_closest_def_repel, dim=-1)
            is_a2_responsible = dist_a2_to_closest_def < h_params['repulsion_proximity_threshold']
            repulsion_reward = h_params['k_repulsion_reward'] * torch.clamp(repulsion_speed, min=0.0) * is_a2_responsible.float()

            # **解决方案**: 最后一次性地将所有分项相加
            dense_reward[:, i] += screen_reward - line_penalty + repulsion_reward
            
        else: # 角色: 防守者 (i=2 or i=3)
            # 1. 越过半场惩罚
            in_defensive_half = agent_pos[:, 1] > 0
            overextend_depth = torch.where(agent_pos[:, 1] < 0, torch.abs(agent_pos[:, 1]) + 1 , torch.zeros_like(agent_pos[:, 1]))
            dense_reward[:, i] -= h_params['k_overextend_penalty'] * overextend_depth
            
            # 2. 有效站位奖励 (引导防守者到A1和篮筐之间的理想位置)
            a1_to_basket_vec = basket_pos - all_pos[:, 0]
            a1_to_basket_norm = torch.linalg.norm(a1_to_basket_vec, dim=-1, keepdim=True) + 1e-6
            a1_to_basket_unit_vec = a1_to_basket_vec / a1_to_basket_norm
            ideal_pos = all_pos[:, 0] + h_params['def_pos_offset'] * a1_to_basket_unit_vec
            dist_to_ideal = torch.linalg.norm(agent_pos - ideal_pos, dim=-1)
            base_positioning_reward = h_params['k_positioning'] * torch.exp(-dist_to_ideal.pow(2) / (2 * h_params['def_pos_sigma']**2))
            
            d_to_a1_vec = agent_pos - all_pos[:, 0]
            proj_dot_product = torch.sum(d_to_a1_vec * a1_to_basket_unit_vec, dim=-1)
            soft_gate_factor_def = torch.sigmoid(5.0 * proj_dot_product) # 门控，确保在A1前方才奖励
            final_positioning_reward = base_positioning_reward * soft_gate_factor_def
            dense_reward[:, i] += final_positioning_reward * in_defensive_half.float() # 只在防守半场生效
            
            # 3. 区域控制奖励 (盯防效果): 当防守者贴近A1时，若A1被迫远离投篮点，则给予防守者奖励
            a1_pos = all_pos[:, 0]
            a1_in_defensive_half = a1_pos[:, 1] > 0
            
            # 条件1: 防守者需要在防守半场，且离A1足够近
            is_guarding_context = in_defensive_half & a1_in_defensive_half
            dist_to_a1 = torch.linalg.norm(agent_pos - a1_pos, dim=-1)
            is_close_enough_to_guard = dist_to_a1 < h_params['def_guard_threshold']
            apply_proximity_mask = is_guarding_context & is_close_enough_to_guard

            # 条件2: A1正在远离投篮点
            vec_a1_to_spot = spot_center_pos - a1_pos
            unit_vec_a1_to_spot = vec_a1_to_spot / (torch.linalg.norm(vec_a1_to_spot, dim=-1, keepdim=True) + 1e-6)
            vel_a1 = all_vel[:, 0]
            radial_vel_towards_spot = torch.sum(vel_a1 * unit_vec_a1_to_spot, dim=-1)
            # A1远离的速度越大，奖励基数越大。只在远离时(速度为负)才计算奖励。
            reward_from_a1_movement = -torch.clamp(radial_vel_towards_spot, max=0.0)

            # 最终奖励 = 奖励基数 * 缩放系数 * 条件掩码
            final_spot_control_reward = h_params['k_spot_control_reward'] * reward_from_a1_movement
            dense_reward[:, i] += final_spot_control_reward * apply_proximity_mask.float()

            # 4. 高斯引导奖励 (吸引防守者向投篮点移动)
            dist_d_to_spot = torch.linalg.norm(agent_pos - spot_center_pos, dim=-1)
            def_gaussian_reward = h_params['k_def_gaussian_spot'] * torch.exp(- (dist_d_to_spot**2) / (2 * h_params['def_gaussian_spot_sigma']**2))
            dense_reward[:, i] += def_gaussian_reward * in_defensive_half.float()
            
        # --- 时间紧迫性惩罚/奖励 ---
        elapsed_time = h_params['t_limit'] - t_remaining.squeeze(-1)
        # 宽限期过后才开始生效
        apply_mask = elapsed_time > h_params['time_penalty_grace_period']
        if torch.any(apply_mask):
            time_factor = (elapsed_time - h_params['time_penalty_grace_period'])**2
            time_value = h_params['k_time_penalty'] * time_factor
            
            if is_attacker:
                # --- 对进攻方的时间惩罚 ---
                # 检查A1是否在投篮区，在则豁免惩罚
                a1_pos = all_pos[:, 0]
                dist_a1_to_spot = torch.linalg.norm(a1_pos - spot_center_pos, dim=1)
                a1_in_spot = (dist_a1_to_spot <= h_params['R_spot']) & (a1_pos[:, 1] > 0)
                
                # 最终生效条件: 基础时间惩罚生效 & A1不在投篮区
                final_penalty_mask = apply_mask & ~a1_in_spot
                dense_reward[final_penalty_mask, i] -= time_value[final_penalty_mask]
            else:
                # --- 对防守方的时间奖励 ---
                dense_reward[apply_mask, i] += time_value[apply_mask]

    return dense_reward, terminal_rewards, dones_out, a1_still_frames_counter, wall_collision_counters, defender_over_midline_counter, attacker_win_this_step
