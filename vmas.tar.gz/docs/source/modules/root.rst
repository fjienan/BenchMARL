vmas
====


.. automodule:: vmas
    :members:
